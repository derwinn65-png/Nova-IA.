# Kits iniciales Roblox Studio (Luau)
1. Abre Roblox Studio y crea tu propia experiencia.
2. Para scripts de servidor, usa ServerScriptService; para interfaz cliente, StarterGui/StarterPlayerScripts.
3. Pide a Nova un kit específico (por ejemplo inventario, monedas, tienda, guardado con DataStore) e indica qué objetos deben existir en Explorer.
4. Revisa y prueba cada script en una experiencia propia antes de publicar.
5. Los IDs de modelos Roblox solo existen después de publicar el recurso; Nova no debe inventarlos.
Este kit no contiene exploits, ejecutores ni trampas para juegos ajenos.
