# Kits iniciales Unity para Nova
Estos son archivos de arranque, no un juego completo ni un compilador remoto.
1. Crea un proyecto 3D en Unity Hub.
2. Copia `NovaPlayerController.cs` a `Assets/Scripts/`.
3. Añade un CharacterController al jugador y asigna el script.
4. Configura Input Manager clásico o adapta los ejes a Input System.
5. Para generar kits nuevos desde Nova, entra en Crear videojuegos y especifica Unity + C# + los archivos que necesitas.
6. Para APK de videojuegos se necesita Unity instalado con Android Build Support y una máquina de compilación aparte. Render Node no sustituye Unity.
